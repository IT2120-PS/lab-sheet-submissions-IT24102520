setwd("C:\\Year 2 sem 2\\PAS\\lab 09\\IT24102520")
getwd()

#Question 01
#Part i
set.seed(123)   
time <- rnorm(25, mean = 45, sd = 2)
time


#Part ii
t.test(time, mu = 46, alternative = "less")


