getwd()
setwd("C:\\Users\\sanet\\Desktop\\Year 2 sem 2\\PAS\\lab 07")

# Read the data set 
data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)



# Question 1

pop_mean <- mean(data$Weight.kg.)
pop_sd   <- sd(data$Weight.kg.)

cat("Population Mean:", pop_mean, "\n")
cat("Population Standard Deviation:", pop_sd, "\n\n")


# Question 2

samples <- c()
n <- c()

set.seed(123) 

for(i in 1:25){
  s <- sample(data$Weight.kg., 6, replace = TRUE) 
  samples <- cbind(samples, s)                     
  n <- c(n, paste('Sample', i, sep=''))            
}

colnames(samples) <- n

# Sample means and SD
s.means <- apply(samples, 2, mean)
s.sds   <- apply(samples, 2, sd)

# Display results in table form
results <- data.frame(
  Sample = 1:25,
  Mean   = s.means,
  SD     = s.sds
)
print(results)


# Question 3

mean_of_means <- mean(s.means)
sd_of_means   <- sd(s.means)

cat("\nMean of 25 Sample Means:", mean_of_means, "\n")
cat("Standard Deviation of 25 Sample Means:", sd_of_means, "\n\n")


#Comparison with True Values

cat("True Mean (Population Mean):", pop_mean, "\n")
cat("True SD (Population SD):", pop_sd, "\n")



